<?php
	// подключение библиотек
	require "inc/lib.inc.php";
	require "inc/config.inc.php";
