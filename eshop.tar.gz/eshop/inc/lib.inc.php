<?php
require_once 'config.inc.php';

// Добавление товара в каталог
function addItemToCatalog($title, $author, $pubyear, $price) {
    global $link;
    $sql = "INSERT INTO catalog (title, author, pubyear, price)
            VALUES (?, ?, ?, ?)";
    if (!$stmt = mysqli_prepare($link, $sql)) {
        return false;
    } else {
        mysqli_stmt_bind_param($stmt, "ssii", $title, $author, $pubyear, $price);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return true;
    }
}

// Выбрка всех товаров
function selectAllItems(){
    global $link;
    $sql = "SELECT id, title, author, pubyear, price FROM catalog WHERE 1";
    $result = mysqli_query($link, $sql);
        if( !$result ){
            return false;
        } else {
        $items = mysqli_fetch_all($result, MYSQLI_ASSOC);
        mysqli_free_result($result);
        return $items;
        }
}

// Сохранение корзины
function saveBasket(){
    global $basket;
    $basket = base64_encode(serialize($basket));
    setcookie('basket', $basket, 0x7FFFFFFF);
}

// Создаем корзину
function basketInit(){
    global $basket;
    global $count;

    // Смотрим есть ли есть корзина. Читаем куку basket
    if (!isset($_COOKIE['basket'])) {
        $basket = ['orderid' => uniqid()];
        saveBasket();
    } else {
        $basket = unserialize(base64_decode($_COOKIE['basket']));
        $count = count($basket) - 1; // Превый элемент всегда orderid (к товару не имеет отношения)
    }
}

//Добавление в корзину
function add2Basket($id){
    global $basket;
    $basket[$id] = 1;
    saveBasket();
}



